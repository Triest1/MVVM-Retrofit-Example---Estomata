package com.example.mvvmretrofitexample.repository;


import com.example.mvvmretrofitexample.retrofit.ApiRequest;
import com.example.mvvmretrofitexample.retrofit.RetrofitRequest;

public class ArticleRepository {
    private static final String TAG = ArticleRepository.class.getSimpleName();
    private final ApiRequest apiRequest;

    public ArticleRepository(){
        apiRequest = RetrofitRequest.getRetrofitInstance().create(ApiRequest.class);
    }

}
